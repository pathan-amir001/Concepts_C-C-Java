#include<stdio.h>

int main()
{
    printf("C programming language...\n");

    return 0;
}

// Step 1 : Compile the code
//  gcc PPA.c -o Myexe

// Step 2 : 
// ./Myexe