#include<stdio.h>

int main()
{
    char cArr[4] = {'A','B','C','D'};



    int iArr[4] = {11,21,51,101};



    float fArr[4] = {10.5,20.5,30.5,40.5};



    double dArr[4] = {11.0,21.0,51.0,101.0};


    return 0;
}