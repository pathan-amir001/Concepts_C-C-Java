#include<iostream>
using namespace std;

int main()
{
    int i = 10;
    const int j = 20;
   //  const int k; NA

    i++;    // Allowed
   // j++;    // NA

    return 0;
}