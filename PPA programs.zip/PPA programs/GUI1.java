import java.awt.*;

class GUI1
{
    public static void main(String Arg[])
    {
        Frame fobj = new Frame("Marvellous");
        fobj.setSize(600,600);
        fobj.setVisible(true);
    }
}