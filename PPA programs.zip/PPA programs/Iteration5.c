#include<stdio.h>

int main()
{
    int i = 1;

    do
    {
        printf("Jay Ganesh...\n");
        i++;  
    }while(i <= 5);

    return 0;
}